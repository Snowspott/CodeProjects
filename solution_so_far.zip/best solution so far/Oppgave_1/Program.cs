﻿
using System.Text.Json;
using System.Threading.Tasks;




namespace Program
{  
    class Read_Objects_From_Json
    {
        static void Main(string[] args)
        {
            // Loads the List...Objekter
            var filelocation_01 = @"/database/Objekter.json";
            String JsonString_01 = File.ReadAllText(filelocation_01);
            var filelocation_02 = @"/database/Object_ID.json";
            String JsonString_02 = File.ReadAllText(filelocation_02).ToString();
            try
            {
                var objekter = JsonSerializer.Deserialize<List<Item>>(JsonString_01);
                var objekt_ID = JsonSerializer.Deserialize<List<Item>>(JsonString_02);
                if(objekter != null || objekt_ID != null)
                {
                    var result_from_asignment = resultSortByAsigment_type2(objekter, objekt_ID);
                }
                else
                {
                    Console.WriteLine("One of the Inputs are empty...");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Invalid Formating On Imput File, Correct formating is: string, string, string");
            }                     

        }

        public static IEnumerable<Item> resultSortByAsigment(List<Item> Objekter, List<Item> Object_ID)  // Løsning Nummer 1, lett og kompakt, men ikke helt hva oppgaven sier. 
        {           
            var list_join_data_equal = from x in Objekter from y in Object_ID where x.ID == y.ID orderby x.KODE select x;
            var list_join_data_not_equal = from x in Objekter where x.ID == null orderby x.KODE select x ;
            var list_join_data_equal_and_not_equal = list_join_data_equal.Concat(list_join_data_not_equal);
            return list_join_data_equal_and_not_equal;
        }

        public static IEnumerable<Item> resultSortByAsigment_type2(List<Item> Objekter, List<Item> Object_ID) // Løsning nummer 2 
        {
            // 1. De objektene som har id i listen over objektid'er skal være først i resultatlisten. (inkludert)
            var list_join_data_equal = from x in Objekter from y in Object_ID where x.ID == y.ID  select x;
            // 2. De objektene som ikke er i listen over objektid'er skal komme til slutt i resultatet. (utelatt)
            var list_join_data_not_equal = from x in Objekter where x.ID == null select x;
			// 3. Resultatet skal deretter sorteres på Kode internt til deres region (inkludert/utelatt)      
            var Sorter_objekter_by_kode =  list_join_data_equal.OrderBy(x => x.KODE);
            var not_equal_by_kode = list_join_data_not_equal.OrderBy(x => x.KODE);
			var list_join_data_equal_and_not_equal = Sorter_objekter_by_kode.Concat(not_equal_by_kode);   //Join those two tables. (inkludert/utelatt)
			
            foreach (var i in list_join_data_equal_and_not_equal)
            {
                Console.WriteLine("Contains ObjektID ID : " + i.ID + " Do have the name of: " + i.NAVN + " Do containt this Kode: " + i.KODE);
            }
            return list_join_data_equal_and_not_equal;
        }
    }

  
    public class Item
    {       
        public string  ID { get; set; }         // Think this is the PK, in "Object_ID", and FK in "Objekter" 
        public string NAVN { get; set; }
        public string KODE { get; set; }
    }
}
