﻿document.addEventListener("drop", function (event) {
    event.preventDefault();
    if (event.target.className == "target" ) {
        var moving_obj = event.dataTransfer.getData("Text");
        event.target.appendChild(document.getElementById(moving_obj));
        count_of_children_elements()
    }
});

document.addEventListener("dragstart", function (event) {
    event.dataTransfer.setData("Text", event.target.id);
});

document.addEventListener("dragover", function (event) {
    event.preventDefault();
});

function count_of_children_elements() {
    var target1 = document.getElementById("target1");
    var counnts_of_target1 = target1.childElementCount

    var target2 = document.getElementById("target2");
    var counnts_of_target2 = target2.childElementCount

    var source = document.getElementById("source");
    var counnts_of_source = source.childElementCount

    document.getElementById("status").innerHTML = "In Object Source are: " + counnts_of_source + "  <br> There is currently= " + counnts_of_target1 + " Item in target1  <br> There is currently= " + counnts_of_target2 + " Item in target2";

    

}
document.addEventListener('DOMContentLoaded', function () {
    count_of_children_elements();
}, false);